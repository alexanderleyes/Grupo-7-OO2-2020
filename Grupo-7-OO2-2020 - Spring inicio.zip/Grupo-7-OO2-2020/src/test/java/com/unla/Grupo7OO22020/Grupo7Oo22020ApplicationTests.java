package com.unla.Grupo7OO22020;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Grupo7Oo22020ApplicationTests {

	@Test
	void contextLoads() {
	}

}
