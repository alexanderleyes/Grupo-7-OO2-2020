package com.unla.Grupo7OO22020;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Grupo7Oo22020Application {

	public static void main(String[] args) {
		SpringApplication.run(Grupo7Oo22020Application.class, args);
	}

}
